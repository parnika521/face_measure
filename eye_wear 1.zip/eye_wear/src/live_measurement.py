import cv2
import mediapipe as mp
import numpy as np

# ------------------ INIT ------------------
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, refine_landmarks=True)
mp_draw = mp.solutions.drawing_utils

# ------------------ LANDMARK IDS ------------------
LEFT_EYE = [33, 133]
RIGHT_EYE = [362, 263]
LEFT_PUPIL = 468
RIGHT_PUPIL = 473
FACE_WIDTH = [234, 454]
NOSE_BRIDGE = [94, 331]

# ------------------ UTILS ------------------
def distance(p1, p2):
    return np.linalg.norm(np.array(p1) - np.array(p2))

def get_point(landmarks, idx, w, h):
    lm = landmarks[idx]
    return int(lm.x * w), int(lm.y * h)

# ------------------ MAIN ------------------
cap = cv2.VideoCapture(0)

print("\n📸 Live face measurement started (mm mode)")
print("➡️ Press Q to quit and print final measurements\n")

final_measurements_mm = {}

# Average PD for scaling
REFERENCE_PD_MM = 63.0  # mm

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = face_mesh.process(rgb)

    if result.multi_face_landmarks:
        landmarks = result.multi_face_landmarks[0].landmark

        # Points
        left_pupil = get_point(landmarks, LEFT_PUPIL, w, h)
        right_pupil = get_point(landmarks, RIGHT_PUPIL, w, h)
        face_left = get_point(landmarks, FACE_WIDTH[0], w, h)
        face_right = get_point(landmarks, FACE_WIDTH[1], w, h)
        nose_left = get_point(landmarks, NOSE_BRIDGE[0], w, h)
        nose_right = get_point(landmarks, NOSE_BRIDGE[1], w, h)

        left_eye_w = distance(
            get_point(landmarks, LEFT_EYE[0], w, h),
            get_point(landmarks, LEFT_EYE[1], w, h)
        )

        right_eye_w = distance(
            get_point(landmarks, RIGHT_EYE[0], w, h),
            get_point(landmarks, RIGHT_EYE[1], w, h)
        )

        pd_px = distance(left_pupil, right_pupil)

        # Scale factor
        mm_per_px = REFERENCE_PD_MM / pd_px

        # Convert all to mm
        final_measurements_mm = {
            "Pupillary Distance (mm)": round(pd_px * mm_per_px, 2),
            "Face Width (mm)": round(distance(face_left, face_right) * mm_per_px, 2),
            "Bridge Width (mm)": round(distance(nose_left, nose_right) * mm_per_px, 2),
            "Left Lens Width (mm)": round(left_eye_w * mm_per_px, 2),
            "Right Lens Width (mm)": round(right_eye_w * mm_per_px, 2)
        }

        # Optional: show live feed
        cv2.line(frame, left_pupil, right_pupil, (0, 255, 0), 2)
        cv2.line(frame, face_left, face_right, (255, 0, 0), 2)
        cv2.line(frame, nose_left, nose_right, (0, 0, 255), 2)

        # Display on screen
        y = 30
        for k, v in final_measurements_mm.items():
            cv2.putText(frame, f"{k}: {v}", (20, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            y += 30

    cv2.imshow("Live Face Measurement (mm)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

# ------------------ PRINT FINAL MEASUREMENTS ------------------
print("\n✅ FINAL FACE MEASUREMENTS (MM)")
print("-----------------------------------")
if final_measurements_mm:
    for k, v in final_measurements_mm.items():
        print(f"{k}: {v}")
else:
    print("No face detected. Please try again.")
